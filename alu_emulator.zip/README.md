# ALU emulator
ALU emulator performing calculations and displaying status flags.
The user is able to performing calculations by entering OP codes and operands from the terminal.
Program code written in C++.
